CZECH MOBILITY - NOVÝ FOTOGRAFICKÝ DASHBOARD

1. Nahraď svůj src/App.jsx souborem:
   src/App.jsx

2. Celou složku:
   public/dashboard
   překopíruj do svého projektu do public/dashboard

Výsledná struktura musí být:

projekt/
├─ src/
│  └─ App.jsx
└─ public/
   └─ dashboard/
      ├─ dashboard-1.webp
      ├─ dashboard-2.webp
      ├─ dashboard-3.webp
      ├─ dashboard-4.webp
      ├─ dashboard-5.webp
      ├─ dashboard-6.webp
      └─ dashboard-7.webp

Slideshow se automaticky přepíná každých 8 sekund.
SQL kvůli dashboardu ani fotkám není potřeba.
